<div align="center">

# SimpleBlog - A Blog Website

SimpleBlog is a completely responsive personal blog website that is compatible with all mobile devices, has Dark and light themes, and is built using HTML, CSS, and JavaScript.

 <a href="https://codingstella.github.io/personal-blog-website/"><strong>➥ Live Demo</strong></a> 
 
 </div>

## License

This project is **free to use** and does not contains any license and Don't Forget to give credit.
