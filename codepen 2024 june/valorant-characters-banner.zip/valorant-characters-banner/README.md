# Valorant Characters Banner

A Pen created on CodePen.io. Original URL: [https://codepen.io/yudizsolutions/pen/bGzKbwm](https://codepen.io/yudizsolutions/pen/bGzKbwm).

I've created a striking CodePen landing page with a GSAP-powered mouse parallax effect, giving it a dynamic touch. The page features a character that playfully follows the mouse cursor, enhancing user interaction. It includes a Slick Slider with unique, dynamically designed slides to engage visitors with diverse visual experiences. Additionally, the landing page is fully responsive, ensuring an optimal display on screens with a minimum width of 1024 pixels. This project blends creative design, interactivity, and responsiveness, making it a standout example of modern web development on CodePen.


Made by Parth Patel from Yudiz