# Responsive Shader Carousel

A Pen created on CodePen.io. Original URL: [https://codepen.io/atzedent/pen/wvOrYMj](https://codepen.io/atzedent/pen/wvOrYMj).

I have a slight tendency to put little shader artefacts into pretty galleries. I found what I was looking for in the 100 most loved pens of last year. 

There is a lot to discover in this one. Even a little hidden pun. If you find it, feel free to leave a comment here. 

Based on the work of: @noirsociety
"Responsive Image Carousel (Animation)"
https://codepen.io/noirsociety/pen/ZEwLGXB

This implementation adds the following features:

- background images rendered from GLSL shaders (two versions: low and full resolution)
- play/pause button to start/stop the shader animation
- swipe gestures on mobile
- keyboard navigation (left/right arrow keys) and spacebar to play/pause

Some less obvious changes:

- despite paused, run animation on resize to adjust to the new resolution
- regenerate the images with full resolution on orientation change