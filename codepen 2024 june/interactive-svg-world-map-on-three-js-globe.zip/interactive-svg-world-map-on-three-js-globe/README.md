# Interactive SVG World Map on Three.js Globe

A Pen created on CodePen.io. Original URL: [https://codepen.io/ksenia-k/pen/zYXZGev](https://codepen.io/ksenia-k/pen/zYXZGev).

