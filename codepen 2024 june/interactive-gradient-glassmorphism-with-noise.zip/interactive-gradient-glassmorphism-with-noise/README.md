# Interactive Gradient & Glassmorphism with noise

A Pen created on CodePen.io. Original URL: [https://codepen.io/Podgro/pen/oNOKYqr](https://codepen.io/Podgro/pen/oNOKYqr).

