# Cards with inverted border-radius #scss

A Pen created on CodePen.io. Original URL: [https://codepen.io/kristen17/pen/pomgrKp](https://codepen.io/kristen17/pen/pomgrKp).

