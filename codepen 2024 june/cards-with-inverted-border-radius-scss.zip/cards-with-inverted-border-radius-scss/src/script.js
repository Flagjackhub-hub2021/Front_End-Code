/* inspiration from
https://cz.pinterest.com/pin/830703093796717544/
*/
