# Bouncy image radio group

A Pen created on CodePen.io. Original URL: [https://codepen.io/argyleink/pen/ExMgWLe](https://codepen.io/argyleink/pen/ExMgWLe).

