# Smooth Liquid Background Effect

A Pen created on CodePen.io. Original URL: [https://codepen.io/tahazsh/pen/gOqNZyw](https://codepen.io/tahazsh/pen/gOqNZyw).

