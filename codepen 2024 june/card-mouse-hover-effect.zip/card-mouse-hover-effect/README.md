# Card Mouse Hover Effect

A Pen created on CodePen.io. Original URL: [https://codepen.io/yudizsolutions/pen/wvZEeNE](https://codepen.io/yudizsolutions/pen/wvZEeNE).

We are using HTML and CSS  to create a card hover animation. We're also using JavaScript for the hover effect.

Made by Ayushi Patel from Yudiz