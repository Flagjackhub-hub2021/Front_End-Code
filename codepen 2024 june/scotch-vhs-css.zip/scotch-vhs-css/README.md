# Scotch VHS CSS

A Pen created on CodePen.io. Original URL: [https://codepen.io/BlurSoulx/pen/zYXJqMy](https://codepen.io/BlurSoulx/pen/zYXJqMy).

