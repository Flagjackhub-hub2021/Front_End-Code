# #CodePenChallenge: Checkbox Stunts - FAQ CSS Only

A Pen created on CodePen.io. Original URL: [https://codepen.io/ismailvtl/pen/QWojMPP](https://codepen.io/ismailvtl/pen/QWojMPP).

