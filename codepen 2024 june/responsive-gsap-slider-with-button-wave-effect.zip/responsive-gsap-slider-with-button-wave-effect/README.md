# Responsive GSAP Slider with Button Wave Effect

A Pen created on CodePen.io. Original URL: [https://codepen.io/yudizsolutions/pen/QWoqmWW](https://codepen.io/yudizsolutions/pen/QWoqmWW).

Explore the mesmerizing world of web design with this slider created using GSAP (GreenSock Animation Platform). Immerse yourself in a  visual experience as the slider smoothly transitions between captivating scenes. The perfect blend of HTML, CSS, and GSAP brings this interactive showcase to life. Click and glide through a seamless journey of creativity and innovation!


Made by Sabur Ahemad Khan from Yudiz