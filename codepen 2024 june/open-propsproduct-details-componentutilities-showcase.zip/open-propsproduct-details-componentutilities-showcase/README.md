# Open Props - Product Details Component - Utilities Showcase

A Pen created on CodePen.io. Original URL: [https://codepen.io/mobalti/pen/MWLLePz](https://codepen.io/mobalti/pen/MWLLePz).

An Accessible Product Details Component built with Open Props