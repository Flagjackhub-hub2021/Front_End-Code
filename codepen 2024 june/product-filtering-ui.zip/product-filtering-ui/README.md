# Product Filtering UI

A Pen created on CodePen.io. Original URL: [https://codepen.io/bradtraversy/pen/oNVKXBo](https://codepen.io/bradtraversy/pen/oNVKXBo).

