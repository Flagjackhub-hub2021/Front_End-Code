# Pure CSS header animation to sticky nav

A Pen created on CodePen.io. Original URL: [https://codepen.io/ghaste/pen/NWJNxGj](https://codepen.io/ghaste/pen/NWJNxGj).

Shows a practical use of animation-timeline - a CSS-based triggering and control of animations, on scrolling and/or visibility in the viewport.

use once it is fully implemented in all browsers