# Responsive macOS Style Portfolio

A Pen created on CodePen.io. Original URL: [https://codepen.io/ecemgo/pen/WNmWVqb](https://codepen.io/ecemgo/pen/WNmWVqb).

Note: Please, do not use it in profit-making platforms and projects without permission.

Inspired by https://codepen.io/stoumann/pen/WNLjodZ