"scripts": {
  "sass": "node-sass scss/style.scss -o css"
}