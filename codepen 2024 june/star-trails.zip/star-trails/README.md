# Star trails

A Pen created on CodePen.io. Original URL: [https://codepen.io/ghaste/pen/YzBJWgL](https://codepen.io/ghaste/pen/YzBJWgL).

Animation Inspired by Hyperplexed: https://www.youtube.com/watch?v=G9207EJySaA