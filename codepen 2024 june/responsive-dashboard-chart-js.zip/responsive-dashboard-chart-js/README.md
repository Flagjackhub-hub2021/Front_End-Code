# Responsive Dashboard | Chart.js

A Pen created on CodePen.io. Original URL: [https://codepen.io/ecemgo/pen/rNbLodN](https://codepen.io/ecemgo/pen/rNbLodN).

In this responsive dashboard, there's the doughnut chart made with Chart.js. It shows the participation rate visually and the number of events by hovering the mouse over the chart.

You can switch between light and dark mode for whatever suits your vibe! Upcoming event cards include like and share buttons. While clicking on the share button, there is a mini popup that contains social media icons. And when you click the like button, you'll see a pulse animation.

Note: Please, do not use it in profit-making platforms and projects without permission.

The other responsive dashboards: 
1) https://codepen.io/ecemgo/pen/MWxjXeq
2) https://codepen.io/ecemgo/pen/YzBZjjb