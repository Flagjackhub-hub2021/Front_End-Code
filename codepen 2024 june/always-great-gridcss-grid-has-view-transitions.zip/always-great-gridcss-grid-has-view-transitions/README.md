# Always great grid - CSS grid + :has() + view transitions

A Pen created on CodePen.io. Original URL: [https://codepen.io/argyleink/pen/RwdRaVg](https://codepen.io/argyleink/pen/RwdRaVg).

