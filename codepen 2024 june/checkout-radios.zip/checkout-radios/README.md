# Checkout Radios

A Pen created on CodePen.io. Original URL: [https://codepen.io/jkantner/pen/RwdVPpd](https://codepen.io/jkantner/pen/RwdVPpd).

Radio options for a checkout page that are organized in small grids. The idea is based on a [Dribbble shot](https://dribbble.com/shots/19200713-Day-023-Radio-Buttons-100-days-UI-challenge) by Dima Groshev.