# Scroll with light (CSS only)

A Pen created on CodePen.io. Original URL: [https://codepen.io/gayane-gasparyan/pen/wvNXyYR](https://codepen.io/gayane-gasparyan/pen/wvNXyYR).

