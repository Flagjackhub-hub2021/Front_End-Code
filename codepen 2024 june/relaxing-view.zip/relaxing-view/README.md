# Relaxing View

A Pen created on CodePen.io. Original URL: [https://codepen.io/atzedent/pen/KKYabdm](https://codepen.io/atzedent/pen/KKYabdm).

The button for the music is in the top right-hand corner.
Here I use a backbuffer to create the effect of the light beams. You can change their direction with the mouse.